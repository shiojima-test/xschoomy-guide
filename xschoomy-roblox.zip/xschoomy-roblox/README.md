# XSchooMy (配布版)

オレンジボードの明るさセンサー値を Roblox に運ぶ「橋」のプログラム一式。

## セットアップ手順

詳しい手順書は教材サイトを参照: https://shiojima-test.github.io/xschoomy-guide/

ざっくりの流れ:

1. **Python 必要ライブラリのインストール** (ターミナル):
   ```bash
   pip3 install pyserial requests python-dotenv
   ```

2. **`.env` ファイルを作る**:
   ```bash
   cp .env.example .env
   ```
   `.env` をテキストエディタで開き、自分の `ROBLOX_API_KEY` と `ROBLOX_UNIVERSE_ID` を書き込む。

3. **`start-xschoomy.command` をダブルクリック** で橋を起動。
   - 停止は `stop-xschoomy.command` をダブルクリック、または起動したターミナルで `Ctrl+C`。
   - 初回ダブルクリック時に「開発元未確認」が出たら、右クリック → 「開く」 で例外承認 (1回だけ)。

4. **Roblox Studio で `roblox/SensorController.luau` を貼り付ける**:
   - Studio → ServerScriptService → 新しい `Script` を追加
   - 名前を `SensorController` に
   - `roblox/SensorController.luau` の中身を全部コピペして保存
   - File → Game Settings → Security → 「Allow HTTP Requests」を ON

## このフォルダの中身

```
xschoomy-roblox/
├─ xschoomy/                     Python 本体 (橋のプログラム)
├─ roblox/
│  └─ SensorController.luau      Roblox 側スクリプト (明るさで空が暗くなる版)
├─ .env.example                  環境変数の雛形 (実値を入れて .env として保存)
├─ requirements.txt              必要な Python ライブラリ一覧
├─ start-xschoomy.command        起動ボタン (ダブルクリック)
└─ stop-xschoomy.command         停止ボタン (ダブルクリック)
```

## 注意

- `.env` は自分の API キーが入っているので、**他人に共有しない / GitHub にあげない**。
- 配布版にはサンプル `.env.example` だけが入っており、本物のキーは含まれていません。

ライセンス: MIT
