#!/bin/bash
# ダブルクリックで XSchooMy を起動するランチャ。
# 中身: このスクリプトと同じ場所にある .venv の python で xschoomy.main を実行するだけ。
# 止めたい時はこのウィンドウで Ctrl+C、または stop-xschoomy.command をダブルクリック。

set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"

if [ ! -x ".venv/bin/python" ]; then
  echo "ERROR: .venv が見つかりません ($DIR/.venv)"
  echo "初回セットアップ手順 (README.md「初回セットアップ」参照):"
  echo "  /opt/homebrew/bin/python3.13 -m venv .venv"
  echo "  .venv/bin/pip install -r requirements.txt"
  echo ""
  echo "Press Enter to close this window."
  read
  exit 1
fi

if [ ! -f ".env" ]; then
  echo "ERROR: .env が見つかりません ($DIR/.env)"
  echo "  cp .env.example .env  をしてから値を埋めてください。"
  echo ""
  echo "Press Enter to close this window."
  read
  exit 1
fi

echo "=== XSchooMy を起動します。Ctrl+C で停止。 ==="
echo "(cwd: $DIR)"
echo ""

exec .venv/bin/python -m xschoomy.main
