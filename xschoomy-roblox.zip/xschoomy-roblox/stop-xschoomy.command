#!/bin/bash
# ダブルクリックで XSchooMy を停止するランチャ。
# 動いている xschoomy.main プロセスを SIGINT で安全終了させる。

PIDS=$(pgrep -f "xschoomy.main" || true)
if [ -z "$PIDS" ]; then
  echo "XSchooMy は起動していません。"
else
  echo "XSchooMy を停止します (PIDs: $PIDS)"
  kill -INT $PIDS 2>/dev/null || true
  sleep 1
  REMAINING=$(pgrep -f "xschoomy.main" || true)
  if [ -n "$REMAINING" ]; then
    echo "  まだ残っているプロセスを SIGKILL: $REMAINING"
    kill -KILL $REMAINING 2>/dev/null || true
  fi
  echo "停止しました。"
fi

echo ""
echo "Press Enter to close this window."
read
