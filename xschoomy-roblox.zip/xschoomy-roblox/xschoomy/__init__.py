"""XSchooMy: SchooMy → Roblox 値の運搬層 (Python パッケージ)。"""
__version__ = "1.0.0"
