"""アプリ設定。`.env` から環境変数を読んで `XSchooMyConfig` を構築する。

設計思想:
  XSchooMy は「判断しない・運ぶだけ」。設定はすべて値ベース。
  スレッショルドやマッピングは持たない。Roblox 側で値→意味の変換を行う。

v1.2.0 で変更:
  noise_threshold を廃止。フィルタは持たない (latest-wins + 固定送信レート)。
  古い .env に NOISE_THRESHOLD=0 が残っていても無害 (読まないだけ)。

v1.4.0 で追加:
  local_http_port を追加。Studio Play は MemoryStore の Studio/production 分離で
  Cloud REST のデータが読めない (Roblox 公式仕様) ため、ローカル HTTP も並行で
  動かして Studio 側は HttpService:GetAsync でローカル取得する。
"""
from __future__ import annotations
import os
from dataclasses import dataclass
from typing import Optional


def _get_env(name: str, default: Optional[str] = None, required: bool = False) -> Optional[str]:
    v = os.environ.get(name, default)
    if required and (v is None or v == ""):
        raise RuntimeError(
            f"環境変数 {name} が未設定です。.env をリポジトリルートに置き、{name}=... を設定してください。"
            " 雛形は .env.example を参照。"
        )
    return v


@dataclass
class XSchooMyConfig:
    """XSchooMy プロセス (= 値を運ぶ層) の設定値を保持する。

    Attributes:
        serial_port: シリアルポート名 (例: /dev/cu.usbserial-0001 / COM3)
        baud_rate: ボーレート (既定 9600)
        api_key: Roblox Open Cloud APIキー
        universe_id: Roblox Universe ID
        pin_code: SchooMy/Roblox 間の識別PIN。queue 名 SchooMyInput_<PIN> の一部
        tx_topic: 送信トピック名 (queue 名の prefix。既定 SchooMyInput)
        tx_interval: **送信ループの固定間隔 (秒)**。v1.2.0 から意味が変わった:
                     reader スレッドは値を最新スロットに上書きするだけ。
                     送信スレッドは tx_interval ごとに最新値だけを POST する。
                     既定 0.1 秒 = 10 回/秒。値を変えると POST レートだけ変わる。
        local_http_port: ローカル HTTP サーバの希望ポート (既定 8000)。使用中なら
                         自動で +50 までの空きを探す。Studio HttpService:GetAsync 用。
        log_level: ログレベル文字列 (DEBUG/INFO/WARN/ERROR)
    """
    serial_port: str
    baud_rate: int = 9600
    api_key: str = ""
    universe_id: str = ""
    pin_code: str = "1234"
    tx_topic: str = "SchooMyInput"
    tx_interval: float = 0.1
    local_http_port: int = 8000
    log_level: str = "INFO"

    @classmethod
    def from_env(cls) -> "XSchooMyConfig":
        """環境変数 (.env で読み込まれていること) から XSchooMyConfig を組み立てる。"""
        # .env を import 時に一度だけロード (python-dotenv が無い場合は静かにスキップ)
        try:
            from dotenv import load_dotenv
            load_dotenv()
        except Exception:
            pass
        return cls(
            serial_port=_get_env("SERIAL_PORT", required=True),
            baud_rate=int(_get_env("BAUD_RATE", "9600")),
            api_key=_get_env("ROBLOX_API_KEY", "", required=False) or "",
            universe_id=_get_env("ROBLOX_UNIVERSE_ID", "", required=False) or "",
            pin_code=_get_env("PIN_CODE", "1234") or "1234",
            tx_topic=_get_env("TX_TOPIC", "SchooMyInput") or "SchooMyInput",
            tx_interval=float(_get_env("TX_INTERVAL", "0.1")),
            local_http_port=int(_get_env("LOCAL_HTTP_PORT", "8000")),
            log_level=(_get_env("LOG_LEVEL", "INFO") or "INFO").upper(),
        )

    def has_roblox_credentials(self) -> bool:
        """API キーと Universe ID が両方揃っているか。

        揃っていれば実送信、不足ならドライランで JSON を標準出力に出す。
        """
        return bool(self.api_key) and bool(self.universe_id)

    def queue_name(self) -> str:
        """MemoryStore のキュー名を組み立てる (Roblox 側と一致必須)。"""
        return f"{self.tx_topic}_{self.pin_code}"
