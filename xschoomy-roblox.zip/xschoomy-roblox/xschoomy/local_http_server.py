"""ローカル HTTP サーバ: Studio Play からの GET /latest に最新センサー値で答える。

なぜ必要か (Roblox 公式仕様で確定):
  MemoryStoreService は **Studio と production で完全に分離** されており、xschoomy が
  Open Cloud REST API で書き込んだデータは **Studio Play からは原理的に読めない**。
  HashMap / SortedMap / MessagingService でも同じ分離が適用される。
  ローカル HTTP は Roblox の Cloud Service 層を経由しないため、この分離問題が無関係。
  Studio Play の HttpService:GetAsync はユーザーの Mac から HTTP を発行するので
  ``http://127.0.0.1:<port>/latest`` に到達できる。

設計:
  - GET /latest        : LatestSlot の現在 snapshot を JSON 1 件で返す (例 {"sensor1": 5.02})
                         キーは可変 (sensor1 〜 sensor3 とか温度センサーとか)。
                         JSON 構造は**フラットな dict** (MemoryStore queue の
                         {pin_code, data:[{...}]} と違う)。Studio 側で簡単に扱えるように。
  - GET /              : 簡易ヘルプ (人間用)
  - その他              : 404
  - 認証無し / localhost only にバインド: ローカル限定なので外部からは到達不可
  - レスポンスに API キー等の秘密情報は含めない (センサー値のみ)
  - 標準ライブラリ http.server のアクセスログは抑制 (xschoomy ロガーと混ぜない)

ポート選択:
  preferred (環境変数 LOCAL_HTTP_PORT、既定 8000) から +50 まで順次トライ。
  起動後、実際に使えた port をログ + 戻り値で返す。READMEには確定 port を載せる。
"""
from __future__ import annotations
import json
import logging
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Optional, Tuple, TYPE_CHECKING

if TYPE_CHECKING:
    from .main import LatestSlot

log = logging.getLogger(__name__)


class _LatestHandler(BaseHTTPRequestHandler):
    """HTTP リクエストハンドラ。クラス属性 ``slot`` に LatestSlot を注入してから使う。"""

    slot: Optional["LatestSlot"] = None
    server_version = "xschoomy-local/1.4"

    def _send_json(self, status: int, payload):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):  # noqa: N802 (BaseHTTPRequestHandler の規約)
        if self.path == "/latest":
            data = self.slot.snapshot() if self.slot is not None else {}
            self._send_json(200, data)
            return
        if self.path == "/" or self.path == "/index.html":
            body = (
                b"xschoomy local HTTP bridge (v1.4)\n"
                b"GET /latest -> JSON of latest sensor dict, e.g. {\"sensor1\": 5.02}\n"
            )
            self.send_response(200)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        self.send_response(404)
        self.send_header("Content-Length", "0")
        self.end_headers()

    def log_message(self, format, *args):  # noqa: A002
        # http.server 標準の access log を抑制 (DEBUG レベルでのみ出す)
        log.debug("http: %s - %s", self.address_string(), format % args)


def start_server(
    slot: "LatestSlot",
    preferred_port: int = 8000,
    bind: str = "127.0.0.1",
    port_search_range: int = 50,
) -> Tuple[ThreadingHTTPServer, int, threading.Thread]:
    """HTTP サーバをデーモンスレッドで起動する。

    Args:
        slot: 最新値を保持する LatestSlot
        preferred_port: 第一希望のポート (既定 8000)
        bind: bind アドレス (既定 127.0.0.1 = localhost のみ)
        port_search_range: preferred から何個まで試すか

    Returns:
        (server, actual_port, thread)
    """
    _LatestHandler.slot = slot
    server: Optional[ThreadingHTTPServer] = None
    chosen_port = preferred_port
    last_err: Optional[Exception] = None
    for try_port in range(preferred_port, preferred_port + port_search_range):
        try:
            server = ThreadingHTTPServer((bind, try_port), _LatestHandler)
            chosen_port = try_port
            break
        except OSError as e:
            last_err = e
            continue
    if server is None:
        raise RuntimeError(
            f"could not bind any port in {preferred_port}..{preferred_port + port_search_range - 1}"
            f" on {bind} (last error: {last_err})"
        )

    t = threading.Thread(target=server.serve_forever, name="xschoomy-http", daemon=True)
    t.start()
    log.info("LocalHttpServer listening on http://%s:%d/latest  (Studio HttpService:GetAsync 用)",
             bind, chosen_port)
    if chosen_port != preferred_port:
        log.warning("LocalHttpServer: preferred port %d was busy; using %d instead. "
                    "Studio 側 SensorController.luau の HTTP_URL を http://%s:%d/latest に合わせること",
                    preferred_port, chosen_port, bind, chosen_port)
    return server, chosen_port, t
