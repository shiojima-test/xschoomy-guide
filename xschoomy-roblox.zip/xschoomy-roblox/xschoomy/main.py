"""SchooMy → Roblox 一本道エントリポイント (v1.4.0: latest-wins + 2 出力経路)。

設計 (運ぶだけ・判断しない):
  - 読み取りスレッド: シリアルを最大速度で読み続け、**最新値スロットを上書き**するだけ。
                     古い値は捨てる。シリアルカーネルバッファを滞留させない。
  - 送信スレッド  : メインスレッドが TX_INTERVAL 秒ごとに最新スロットを取り、
                     RobloxEngine.send() を呼ぶ (本番 live game 用 / Open Cloud MemoryStore)。
                     直前送信と完全に同一 dict なら重複送信を省く (デデュプリのみ)。
  - ローカル HTTP サーバ: 起動時に LocalHttpServer をデーモンスレッドで起動。
                     GET /latest で最新値 dict を JSON で返す (Studio Play 用)。
                     Studio MemoryStore は production と分離されている (Roblox 公式仕様) ため
                     Cloud REST 経由ではテスト不能。ローカル HTTP で経路を別途確保する。

  Studio 側は RunService:IsStudio() で経路を分岐:
    - Studio Play          → http://127.0.0.1:<port>/latest を GetAsync (このサーバ)
    - 公開された live game → MemoryStore queue を ReadAsync (Open Cloud POST と相互可視)

なぜこの設計か (v1.1.0 の問題):
  シリアル ~700 行/秒 + 同期 POST 300ms 以上 → POST が処理を滞らせ、シリアル
  カーネル ring バッファに古いデータが滞留。覆って "3" が出ても何分も後まで届かなかった。
  latest-wins にすることで、シリアルバッファは即 drain、最新値が常に TX_INTERVAL
  以内に Roblox へ届く。

動的キー (v1.1.0 から維持):
  値の個数は判断しない。1 値なら {"sensor1": v}、3 値なら sensor1/2/3。
  明るさセンサーでも加速度3軸でも同じコードで動く。

破損行ハンドリング (v1.2.0 で強化):
  parse_csv_line が None を返したら捨てる。判定基準は serial_handler.py 参照
  (1: float 失敗、2: 絶対値が MAX_VALUE_MAGNITUDE 超え)。

Usage:
  $ python -m xschoomy.main         # 通常 (.env を読む)
  $ python -m xschoomy.main --dry   # API キー未取得時のドライラン (HTTPは投げない)
"""
from __future__ import annotations
import argparse
import logging
import signal
import sys
import threading
import time
from typing import Dict, Optional

from .app_config import XSchooMyConfig
from .serial_handler import SerialReader, parse_csv_line
from .roblox_engine import RobloxEngine
from .local_http_server import start_server as start_local_http_server


log = logging.getLogger("xschoomy")


# 値の個数は判断しない。来た数だけ sensor1, sensor2, ... と動的に振る。
MAX_FIELDS = 64  # 安全弁。通常運用では到底届かない上限。超過時は WARN だけ出して切る。
HEARTBEAT_SEC = 5.0  # 何秒ごとに「alive」統計ログを出すか


def values_to_sensor_dict(values):
    """``[1.2, -0.3, 0.0]`` → ``{"sensor1": 1.2, "sensor2": -0.3, "sensor3": 0.0}``。

    値の個数は問わない。0 個なら空 dict。
    """
    n = len(values)
    if n > MAX_FIELDS:
        log.warning("field count %d exceeds MAX_FIELDS=%d; extra fields will be ignored", n, MAX_FIELDS)
        n = MAX_FIELDS
    return {f"sensor{i + 1}": values[i] for i in range(n)}


class LatestSlot:
    """reader からの最新値を保持する共有スロット (lock 保護)。

    update() で **上書き** (古い値は捨てる)、snapshot() で現在の dict コピーを返す。
    統計のため reads (更新回数) / drops (parse 失敗で捨てた行数) も持つ。
    """
    def __init__(self):
        self._data: Dict[str, float] = {}
        self._lock = threading.Lock()
        self.reads = 0
        self.drops = 0  # parse 失敗 or 破損行で捨てた数

    def update(self, data: Dict[str, float]) -> None:
        with self._lock:
            self._data = data
            self.reads += 1

    def drop(self) -> None:
        with self._lock:
            self.drops += 1

    def snapshot(self) -> Dict[str, float]:
        with self._lock:
            return dict(self._data)


def reader_worker(reader: SerialReader, slot: LatestSlot, stop_event: threading.Event) -> None:
    """シリアルから値を読み続け、最新値スロットを上書きする。

    パース失敗・破損行は捨てて drops を加算。
    """
    for text in reader.iter_lines(stop_event):
        values = parse_csv_line(text)
        if values is None or not values:
            slot.drop()
            log.debug("skip line: %r", text)
            continue
        slot.update(values_to_sensor_dict(values))


def parse_args() -> argparse.Namespace:
    ap = argparse.ArgumentParser(description="XSchooMy: SchooMy → Roblox 値の運搬層")
    ap.add_argument(
        "--dry",
        action="store_true",
        help="HTTP を投げず、組み立てたペイロードをログに出すだけ (API キー未取得時の動作確認用)",
    )
    return ap.parse_args()


def setup_logging(level_name: str) -> None:
    level = getattr(logging, level_name.upper(), logging.INFO)
    logging.basicConfig(
        level=level,
        format="%(asctime)s %(levelname)-5s %(name)s | %(message)s",
        datefmt="%H:%M:%S",
    )


def run(config: XSchooMyConfig, dry_run: bool) -> int:
    stop_event = threading.Event()

    def handle_sig(signum, frame):  # noqa: ARG001
        log.info("Signal %s received → stopping", signum)
        stop_event.set()

    signal.signal(signal.SIGINT, handle_sig)
    signal.signal(signal.SIGTERM, handle_sig)

    engine = RobloxEngine(config, dry_run=dry_run)
    engine.start()
    if dry_run:
        log.info("dry-run モードで起動 (HTTPは投げません)")
    elif not config.has_roblox_credentials():
        log.warning("ROBLOX_API_KEY / ROBLOX_UNIVERSE_ID が未設定。自動的に dry-run モードへフォールバックします")
        engine.dry_run = True

    reader = SerialReader(config.serial_port, config.baud_rate, read_timeout=1.0)
    try:
        reader.open()
    except FileNotFoundError:
        log.error("シリアルポートが見つかりません: %s", config.serial_port)
        return 2
    except PermissionError as e:
        log.error("シリアルポート権限エラー: %s", e)
        return 2
    except Exception as e:
        log.error("シリアルポートのオープンに失敗: %s", e)
        return 2

    slot = LatestSlot()

    # reader を別スレッドで起動 (古い値は読み流して slot を最新で上書きし続ける)
    reader_thread = threading.Thread(
        target=reader_worker, args=(reader, slot, stop_event),
        name="xschoomy-reader", daemon=True,
    )
    reader_thread.start()
    log.info("reader thread started; send loop interval=%.3fs (%.1f Hz)",
             config.tx_interval, 1.0 / max(config.tx_interval, 1e-6))

    # ローカル HTTP サーバを起動 (Studio Play からの GET /latest 用)
    # Cloud REST → Studio Play の経路は Roblox 仕様で分離されているための代替経路。
    http_server = None
    http_port = None
    try:
        http_server, http_port, _ = start_local_http_server(slot, preferred_port=config.local_http_port)
    except Exception as e:
        log.error("LocalHttpServer 起動失敗: %s — Studio Play 経路が機能しません", e)

    # メインスレッドが固定間隔で最新値を POST
    last_dispatched: Optional[Dict[str, float]] = None
    sent_count = 0
    last_heartbeat = time.time()
    last_heartbeat_reads = 0

    try:
        while not stop_event.is_set():
            # 固定送信間隔。stop_event は途中で set されたら即抜ける
            stop_event.wait(config.tx_interval)
            if stop_event.is_set():
                break

            snapshot = slot.snapshot()
            if not snapshot:
                # まだ reader が1行も読めていない (起動直後 / キャリブレーション中) 場合
                continue

            # 直前送信と同一 dict なら重複送信を省く (デデュプリのみ。フィルタではない)
            if snapshot != last_dispatched:
                engine.send(snapshot)
                last_dispatched = snapshot
                sent_count += 1
                log.info("sent #%d %s", sent_count, snapshot)

            # ハートビート (5秒に1回): reader レート・drops 数・最新値を表示
            now = time.time()
            elapsed = now - last_heartbeat
            if elapsed >= HEARTBEAT_SEC:
                rate = (slot.reads - last_heartbeat_reads) / elapsed
                log.info("alive reads=%d drops=%d rate=%.0f/s sent=%d latest=%s",
                         slot.reads, slot.drops, rate, sent_count, snapshot)
                last_heartbeat = now
                last_heartbeat_reads = slot.reads
    finally:
        stop_event.set()
        reader_thread.join(timeout=2.0)
        if http_server is not None:
            try:
                http_server.shutdown()
            except Exception:
                pass
        engine.stop()
        reader.close()
        log.info("Stopped. reads=%d drops=%d sent=%d", slot.reads, slot.drops, sent_count)
    return 0


def main() -> int:
    args = parse_args()
    try:
        config = XSchooMyConfig.from_env()
    except RuntimeError as e:
        print(f"設定エラー: {e}", file=sys.stderr)
        return 2
    setup_logging(config.log_level)
    log.info("config: port=%s baud=%d queue=%s pin=%s tx_interval=%.3fs http_port=%d",
             config.serial_port, config.baud_rate, config.queue_name(),
             config.pin_code, config.tx_interval, config.local_http_port)
    return run(config, dry_run=args.dry)


if __name__ == "__main__":
    sys.exit(main())
