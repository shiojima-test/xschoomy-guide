"""Roblox Open Cloud MemoryStore へ値を運ぶエンジン (v1.2.0: フィルタ無し版)。

設計 (運ぶだけ・判断しない):
  - 渡された dict を そのまま MemoryStore queue に POST する。
  - 値の大小・前回比較・スムージング等の「判断」は **一切行わない**。
  - 429 (Rate Limit) を受けた時だけ短時間 (1秒) スリープして自然回復を待つ。
  - 同期 HTTP (requests) でシンプル実装。送信レート制御は呼び出し側 (main.py の送信ループ) が行う。
"""
from __future__ import annotations
import json
import logging
import time
import urllib.parse
from typing import Dict, Optional

import requests

from .app_config import XSchooMyConfig

log = logging.getLogger(__name__)


class RobloxEngine:
    """値 dict を受け取り、MemoryStore キューへ POST する。

    Attributes:
        config: XSchooMyConfig
        dry_run: True なら HTTP は呼ばず、組み立てたペイロードをログ出力するだけ
                 (API キー未取得時の動作確認に便利)
    """

    def __init__(self, config: XSchooMyConfig, dry_run: bool = False):
        self.config = config
        self.dry_run = dry_run
        self._rate_limit_pause_until: float = 0.0

        self._session: Optional[requests.Session] = None
        self._url: Optional[str] = None

    def start(self) -> None:
        """HTTPセッションを準備。dry_run でも呼んでよい (URL ログ用に組み立てる)。"""
        queue_raw = self.config.queue_name()
        queue_enc = urllib.parse.quote(queue_raw, safe="")
        self._url = (
            f"https://apis.roblox.com/cloud/v2/universes/"
            f"{self.config.universe_id}/memory-store/queues/{queue_enc}/items"
        )
        if self.dry_run:
            log.info("[dry-run] would POST to %s", self._url)
            return
        s = requests.Session()
        s.headers.update({
            "x-api-key": self.config.api_key,
            "Content-Type": "application/json",
        })
        self._session = s
        log.info("RobloxEngine ready. queue=%s url=%s", queue_raw, self._url)

    def stop(self) -> None:
        if self._session:
            self._session.close()
            self._session = None

    def send(self, data: Dict[str, float]) -> None:
        """値 dict をそのまま POST する。フィルタ・前回比較なし。

        Args:
            data: 例 ``{"sensor1": 12.34}``。空 dict なら何もしない。
        """
        if not data:
            return

        # 429 受信後の冷却期間中はスキップ (これだけは性能上必要)
        if time.time() < self._rate_limit_pause_until:
            return

        # Roblox 側 (SensorController.luau) と合わせた形:
        #   外側: {"data": "<JSON文字列>", "ttl": "30s"}
        #   内側JSON文字列: {"pin_code": "1234", "data": [{<keys>}]}
        inner = {"pin_code": self.config.pin_code, "data": [data]}
        payload = {"data": json.dumps(inner), "ttl": "30s"}

        if self.dry_run:
            log.info("[dry-run] POST %s payload=%s", self._url, payload)
            return

        try:
            res = self._session.post(self._url, json=payload, timeout=5.0)
        except Exception as e:
            log.warning("POST exception: %s", e)
            return

        if res.status_code == 200:
            log.debug("POST 200 keys=%s", list(data.keys()))
        elif res.status_code == 429:
            self._rate_limit_pause_until = time.time() + 1.0
            log.warning("429 rate limit hit. pausing 1.0s")
        else:
            log.warning("POST %d body=%s", res.status_code, res.text[:200])
