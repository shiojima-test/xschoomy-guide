"""シリアルからCSV行を読み出すハンドラ。

実装メモ (Mac固有のpyserialバグ回避):
  - pyserial 3.5 は macOS 14+ で一部のUSB-serialドライバ (CH340 等) に対し
    `termios.tcsetattr` で EINVAL を返す既知の問題がある。
  - 回避: Mac/Linux では `os.open()` + `select` で生 POSIX read を行う
    (ボーレートはデバイス側 / 既存ttyの状態を尊重し、明示再設定しない)。
  - Windows では pyserial の `serial.Serial` をそのまま使う。

公開IF (SerialReader):
  - open() / close()
  - iter_lines(stop_event=None) ジェネレータ。1行ずつ str を yield (空行は飛ばす)。

「橋は判断しない」原則:
  - 数値変換できない行 (キャリブレーション文言など) は **値として扱わず**、
    `parse_csv_line` で None を返す。利用側で None なら送らない、で済む形にする。
"""
from __future__ import annotations
import os
import sys
import time
import select
import logging
from typing import Iterator, List, Optional


log = logging.getLogger(__name__)


MAX_VALUE_MAGNITUDE = 1000.0
"""破損行検出の閾値: 値の絶対値がこれを超えたら、その行ぜんぶ捨てる。

意味:
  USB シリアルのバイト境界破壊で隣接する 2 行が連結すると、たとえば
  ``"53.94" + "54.00" → "5394.0"`` や、ドット消失で ``"554.0" / "394.0"`` のような
  桁外れの値が現れる。MAX_VALUE_MAGNITUDE を超える値はこの種の破損とみなして刈る。

なぜ 1000 か:
  現実的なセンサーの妥当域はすべて 1000 未満で収まるため、正常値を巻き込まない。
    - 明るさ        : 0..110
    - 傾き (角度)   : ±360°
    - 加速度        : ±20g 程度
    - 温度          : -50..150°C
    - 気圧 (hPa)    : 850..1100
    - 磁気 (μT)     : ±500
  これより大きい値が出るセンサーを将来追加するときは、ここを書き換える
  (判断基準は 1 箇所にまとまっている)。

なぜ環境変数にしないか:
  破損検出のロジックそのものであり、運用者が日々調整するものではない。
  日常運用で触る値ではないので .env ではなくコード定数として固定。
  変更頻度の高いもの (TX_INTERVAL 等) は .env、低いものはコード、で分けている。
"""


def parse_csv_line(line: str) -> Optional[List[float]]:
    """CSV1行を float リストへパース。破損や非数値は None を返す (行ごと捨てる)。

    破損判定の基準 (v1.2.0):
      1) ``float()`` パース失敗 → 例 ``"53..494"`` ``"53.34.94"`` ``"Calculate Calibration..."``
      2) いずれかの値の絶対値が ``MAX_VALUE_MAGNITUDE`` を超える
         → 例 ``"5394.0"`` ``"53354.0"`` (バイト境界破壊で連結された巨大数)

    判定は **行単位**。1 つでも怪しい値があれば、その行ぜんぶ捨てる。
    部分採用しない (運ぶだけ・判断しない設計の徹底)。

    例:
      ``"12.34, -5.67, 0.12"``  → [12.34, -5.67, 0.12]
      ``"Calculate Calibration..."`` → None
      ``""`` → None
      ``"5394.0"`` → None (絶対値 > MAX_VALUE_MAGNITUDE)
      ``"53..494"`` → None (parse 失敗)
    """
    line = line.strip()
    if not line:
        return None
    parts = [p.strip() for p in line.split(",")]
    try:
        values = [float(p) for p in parts]
    except ValueError:
        return None
    for v in values:
        if abs(v) > MAX_VALUE_MAGNITUDE:
            return None
    return values


class _PosixBackend:
    """POSIX (Mac/Linux) 用の最小バックエンド。`os.read` + `select` ベース。"""

    def __init__(self, port: str, baudrate: int, read_timeout: float = 1.0):
        self.port = port
        self.baudrate = baudrate
        self.read_timeout = read_timeout
        self._fd: Optional[int] = None
        self._buf = b""

    def open(self) -> None:
        # マック側はデバイス接続時のkernel設定 (USB-CDCが9600で記述) を尊重し、
        # termios再設定はしない (pyserialのEINVALを踏まない)。
        self._fd = os.open(self.port, os.O_RDONLY | os.O_NOCTTY | os.O_NONBLOCK)

    @property
    def is_open(self) -> bool:
        return self._fd is not None

    def close(self) -> None:
        if self._fd is not None:
            try:
                os.close(self._fd)
            finally:
                self._fd = None

    def reset_input_buffer(self) -> None:
        """貯まっている入力を捨てる。"""
        if self._fd is None:
            return
        try:
            while True:
                r, _, _ = select.select([self._fd], [], [], 0)
                if not r:
                    break
                try:
                    chunk = os.read(self._fd, 4096)
                except BlockingIOError:
                    break
                if not chunk:
                    break
        except Exception:
            pass
        self._buf = b""

    def readline(self) -> bytes:
        """1行 (改行込み) を返す。タイムアウト時は b''。"""
        if self._fd is None:
            return b""
        deadline = time.time() + self.read_timeout
        while b"\n" not in self._buf:
            remaining = deadline - time.time()
            if remaining <= 0:
                return b""
            r, _, _ = select.select([self._fd], [], [], min(remaining, 0.2))
            if r:
                try:
                    chunk = os.read(self._fd, 4096)
                except BlockingIOError:
                    chunk = b""
                if chunk:
                    self._buf += chunk
                else:
                    # EOF (デバイスが抜けた)
                    return b""
        line, sep, rest = self._buf.partition(b"\n")
        self._buf = rest
        return line + sep


class _PySerialBackend:
    """Windows 用 (pyserial)。"""

    def __init__(self, port: str, baudrate: int, read_timeout: float = 1.0):
        import serial  # 遅延 import
        self._serial_mod = serial
        self.port = port
        self.baudrate = baudrate
        self.read_timeout = read_timeout
        self._ser = None

    def open(self) -> None:
        self._ser = self._serial_mod.Serial(
            self.port, self.baudrate, timeout=self.read_timeout
        )

    @property
    def is_open(self) -> bool:
        return bool(self._ser and self._ser.is_open)

    def close(self) -> None:
        if self._ser:
            try:
                self._ser.close()
            except Exception:
                pass
            self._ser = None

    def reset_input_buffer(self) -> None:
        if self._ser:
            try:
                self._ser.reset_input_buffer()
            except Exception:
                pass

    def readline(self) -> bytes:
        if not self._ser:
            return b""
        return self._ser.readline()


class SerialReader:
    """シリアル読み出しのプラットフォーム抽象。

    用法:
        with SerialReader(port, baud) as r:
            for line in r.iter_lines(stop_event):
                ...
    """

    def __init__(self, port: str, baudrate: int = 9600, read_timeout: float = 1.0):
        self.port = port
        self.baudrate = baudrate
        if sys.platform.startswith("win"):
            self._backend = _PySerialBackend(port, baudrate, read_timeout)
        else:
            self._backend = _PosixBackend(port, baudrate, read_timeout)

    def open(self) -> None:
        log.info("Opening %s @ %d bps (%s backend)", self.port, self.baudrate, type(self._backend).__name__)
        self._backend.open()
        # ボードのリセット出力などを少し待ってバッファを捨てる
        time.sleep(0.5)
        self._backend.reset_input_buffer()

    def close(self) -> None:
        log.info("Closing %s", self.port)
        self._backend.close()

    def __enter__(self) -> "SerialReader":
        self.open()
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def iter_lines(self, stop_event=None) -> Iterator[str]:
        """`stop_event.is_set()` が True になるまで1行ずつ yield。

        - 空行はスキップ
        - デコード失敗は errors='replace'
        - デバイス抜けで b'' が連続したら短い sleep を入れて再試行 (=自動回復は呼び出し側)
        """
        consecutive_empty = 0
        while True:
            if stop_event is not None and stop_event.is_set():
                return
            raw = self._backend.readline()
            if not raw:
                consecutive_empty += 1
                if consecutive_empty > 5:
                    time.sleep(0.1)
                continue
            consecutive_empty = 0
            try:
                text = raw.decode("utf-8", errors="replace").strip()
            except Exception:
                continue
            if not text:
                continue
            yield text
